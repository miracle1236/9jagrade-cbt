"use client";
import {useEffect,useState} from "react";
import Link from "next/link";
import {supabase} from "@/lib/supabase";

export default function Dashboard(){
 const [name,setName]=useState("Student"),[cbts,setCbts]=useState<any[]>([]),[attempts,setAttempts]=useState<any[]>([]),[code,setCode]=useState(""),[err,setErr]=useState("");
 useEffect(()=>{(async()=>{
  const {data:{user}}=await supabase.auth.getUser(); if(!user){location.href="/login";return;}
  const {data:p}=await supabase.from("profiles").select("full_name").eq("id",user.id).maybeSingle(); setName(p?.full_name||user.user_metadata?.full_name||"Student");
  const {data:c}=await supabase.from("cbts").select("id,title,description,access_code,duration_minutes,pass_mark,show_leaderboard").eq("status","published").order("created_at",{ascending:false}).limit(12); setCbts(c||[]);
  const {data:a}=await supabase.from("attempts").select("id,cbt_id,score,total_marks,percentage,submitted_at,status,cbts(title)").eq("student_id",user.id).order("created_at",{ascending:false}).limit(6); setAttempts(a||[]);
 })()},[]);
 async function find(){setErr("");const v=code.trim().toUpperCase();if(!v){setErr("Enter a CBT code.");return;}const {data}=await supabase.from("cbts").select("id").eq("access_code",v).eq("status","published").maybeSingle();if(!data){setErr("CBT code not found.");return;}location.href="/cbt/"+v;}
 return <main className="container dashboard"><section className="dashHero"><div><span className="eyebrow">9jaGrade CBT</span><h1>Welcome, {name.split(" ")[0]} 👋</h1><p>Practice, take exams and track your performance in one place.</p></div><Link href="/" className="btn btn-secondary">Explore 9jaGrade</Link></section>
  <section className="joinCard card"><div><span className="eyebrow">Have a CBT code?</span><h2>Enter your exam code</h2><p className="muted">Use the code provided by your tutor or school.</p></div><div className="joinForm"><input className="input" value={code} onChange={e=>setCode(e.target.value)} placeholder="e.g. CPE21426"/><button className="btn btn-primary" onClick={find}>Find CBT</button></div>{err&&<p className="error">{err}</p>}</section>
  <div className="sectionHead"><div><h2 className="title">Available CBTs</h2><p className="muted">Published exams ready to take.</p></div></div>
  <section className="grid">{cbts.map(c=><article className="card cbtCard" key={c.id}><div className="cardTop"><span className="pill">Published</span><span className="small muted">{c.duration_minutes} min</span></div><h3>{c.title}</h3><p className="muted">{c.description||"Computer Based Test by 9jaGrade."}</p><div className="meta"><span>Pass: {c.pass_mark}%</span><span>Code: <b>{c.access_code}</b></span></div><Link href={`/cbt/${c.access_code}`} className="btn btn-primary full">View & Start</Link></article>)}{!cbts.length&&<div className="card empty"><h3>No published CBTs yet</h3><p className="muted">Your available exams will appear here.</p></div>}</section>
  <div className="sectionHead" style={{marginTop:40}}><div><h2 className="title">Recent attempts</h2><p className="muted">Your latest CBT performance.</p></div></div>
  <section className="card tablewrap"><table className="table"><thead><tr><th>CBT</th><th>Score</th><th>Percentage</th><th>Status</th><th></th></tr></thead><tbody>{attempts.map(a=><tr key={a.id}><td>{a.cbts?.title||"CBT"}</td><td>{a.score}/{a.total_marks}</td><td><b>{a.percentage}%</b></td><td><span className="pill">{a.status}</span></td><td><Link href={`/result/${a.id}`} className="textLink">View result</Link></td></tr>)}{!attempts.length&&<tr><td colSpan={5} className="muted">No attempts yet.</td></tr>}</tbody></table></section>
 </main>
}
