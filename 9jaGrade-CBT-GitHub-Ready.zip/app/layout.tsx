import "./globals.css";
import { Nav } from "@/components/Nav";
export const metadata={title:"9jaGrade CBT",description:"9jaGrade Computer Based Tests"};
export default function RootLayout({children}:{children:React.ReactNode}){return <><Nav/>{children}<footer className="footer"><div className="container">© 9jaGrade — Nigeria’s Exam Plug</div></footer></>}